def q1():
    a=int(input())
    b=int(input())
    add=a+b
    print(add)
