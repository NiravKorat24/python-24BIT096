def q10():
    dollar=float(input("Enter the value of dollars:"))
    pounds=70/48*dollars
    print("The value in pounds is",pounds)
