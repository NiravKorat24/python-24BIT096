def q11():
    grams=float(input("Enter the weight in grams:"))
    kilograms=grams/1000
    print("The weight in kgs is",kilograms)
