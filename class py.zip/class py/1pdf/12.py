def q12():
    kilograms=float(input("Enter the weight in kilograms:"))
    grams=kilograms*1000
    print("The weight in grams is",grams)
