def q14():
    C=float(input("Enter temperature in celcius"))
    F = (9/5*C) + 32
    print("The temperature in farenheit is",F)
