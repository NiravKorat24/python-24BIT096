def q15():
    F=float(input("Enter temperature in Farenheit"))
    C = 5/9*(F-32)
    print("The temperature in celcius is",C)
