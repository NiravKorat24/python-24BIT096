def q16():
    P=float(input("Enter the principal amount"))
    R=float(input("Enter the Rate of intrest"))
    N=float(input("Enter the duration of loan in years"))
    I = P*R*N/100
    print("The Intrest amount is Rs",I)
