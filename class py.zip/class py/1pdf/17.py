def q17():
    side=float(input("Enter the length of square"))
    A=side**2
    P=4*side
    print("The Area of square is",A)
    print("The Perimeter of square is",P)
