def q18():
    length=float(input("Enter the length of rectangle"))
    width=float(input("Enter the width of rectangle"))
    A=length*width
    P=2*(length+width)
    print("The Area of rectangle is",A)
    print("The Perimeter of rectangle is",P)
