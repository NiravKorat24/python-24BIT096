def q19():
    radius=float(input("Enter the radius of circle"))
    A=22/7*radius**2
    P=2*22/7*radius
    print("The Area of circle is",A)
    print("The Perimeter of circle is",P)
