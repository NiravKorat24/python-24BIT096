def q2():
    a=int(input())
    b=int(input())
    sub=a-b
    print(sub)
