def q20():
    base=float(input("Enter the base of triangle"))
    height=float(input("Enter the height of triangle"))
    A=base*height/2
    print("The area of triangle is",A)
