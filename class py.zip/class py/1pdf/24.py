def q24():
    a=int(input("Enter value of a"))
    b=int(input("Enter value of b"))

    a,b=b,a
    print("The value of a after swap is",a)
    print("The value of b after swap is",b)
    
