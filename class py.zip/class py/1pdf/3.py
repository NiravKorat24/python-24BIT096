def q3():
    a=int(input())
    b=int(input())
    product=a*b
    print(product)
