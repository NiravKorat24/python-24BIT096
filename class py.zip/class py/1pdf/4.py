def q4():
    a=int(input())
    b=int(input())
    div=a/b
    print(div)
