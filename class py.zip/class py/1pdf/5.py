def q5():
    a=int(input())
    b=int(input())
    add=a+b
    print(add)
    sub=a-b
    print(sub)
    product=a*b
    print(product)
    div=a/b
    print(div)
