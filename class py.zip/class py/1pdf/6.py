def q6():
    minutes=float(input("Enter the no of minutes:"))
    hours=minutes/60
    print("The minutes in hours is",hours)
