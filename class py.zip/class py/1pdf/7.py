def q7():
    hours=float(input("Enter the no of hours:"))
    minutes=hours*60
    print("The hours in minutes is",minutes)
