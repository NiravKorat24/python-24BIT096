def q8():
    dollar=float(input("Enter the value of dollars:"))
    rupees=dollar*48
    print("The Dollar in Rupees is:",rupees)
