def q9():
    rupees=float(input("Enter the value of Rupees:"))
    dollar=rupees/48
    print("The Rupees in Dollar is:",rupees)
