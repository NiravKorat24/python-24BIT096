def q2():
    def compute(n:int):
        result=1
        for i in range(4):
            result*=n
        return result
    for i in range(4,8):
        print(f"The ans for {i} is",compute(i))
q2()
    
