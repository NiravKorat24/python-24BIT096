def q1():
    n1=int(input("First Number:"))
    n2=int(input("Second Number:"))
    
    if(n1>n2):
        print(n1,"is larger and",n2,"is smaller value") 
    else:
        print(n2,"is larger and",n1,"is smaller value") 
