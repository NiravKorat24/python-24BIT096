def q4():
    num=int(input("Enter any no"))
    print("Divisible by 10") if(num%10==0) else print("Not divisible by 10")