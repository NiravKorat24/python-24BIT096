def q5():
    age=int(input("Enter your age"))
    print("Major") if(age>18) else print("Minor")