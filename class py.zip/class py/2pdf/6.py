def q6():
    num=int(input("Enter any number:"))
    str_num=str(num)
    print("The number of digits in number is",len(str_num))
