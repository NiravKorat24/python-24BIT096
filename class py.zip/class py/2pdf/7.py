def q7():
    year=int(input("Enter any year"))
    print("It is a leap year") if(year%4==0) else print("It is not leap year")