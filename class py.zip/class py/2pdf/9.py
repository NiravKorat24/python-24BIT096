def q9():
    x=int(input("Enter any no"))
    print(x) if(x>0) else print(x*-1)
