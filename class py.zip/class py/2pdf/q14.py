def q14():
    sub1=float(input("Enter the marks in subject 1"))
    sub2=float(input("Enter the marks in subject 2"))
    sub3=float(input("Enter the marks in subject 3"))
    total=sub1+sub2+sub3
    average=total/3
    if(sub1<=39 or sub2<=39 or sub3<=39 ):
        print("sorry bro you are fail!!!")



    if(100<=sub1<=80):
        print("your grade in sub1 is O")
    elif(70<=sub1<=79):
        print("your grade in sub1 is A+")
    elif(60<=sub1<=69):
        print("your grade in sub1 is A")
    elif(55<=sub1<=59):
        print("your grade in sub1 is B+")
    elif(50<=sub1<=54):
        print("your grade in sub1 is B")
    elif(45<=sub1<=49):
        print("your grade in sub1 is C")
    elif(40<=sub1<=44):
        print("your grade in sub1 is P")
    else:
        print("your grade in sub1 is F")

    if(100<=sub2<=80):
        print("your grade in sub2 is O")
    elif(70<=sub2<=79):
        print("your grade in sub2 is A+")
    elif(60<=sub2<=69):
        print("your grade in sub2 is A")
    elif(55<=sub2<=59):
        print("your grade in sub2 is B+")
    elif(50<=sub2<=54):
        print("your grade in sub2 is B")
    elif(45<=sub2<=49):
        print("your grade in sub2 is C")
    elif(40<=sub2<=44):
        print("your grade in sub2 is P")
    else:
        print("your grade in sub2 is F")
    

    if(100<=sub3<=80):
        print("your grade in sub3 is O")
    elif(70<=sub3<=79):
        print("your grade in sub3 is A+")
    elif(60<=sub3<=69):
        print("your grade in sub1 is A")
    elif(55<=sub3<=59):
        print("your grade in sub3 is B+")
    elif(50<=sub3<=54):
        print("your grade in sub3 is B")
    elif(45<=sub3<=49):
        print("your grade in sub3 is C")
    elif(40<=sub3<=44):
        print("your grade in sub3 is P")
    else:
        print("your grade in sub3 is F")

