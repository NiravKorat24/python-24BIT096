def q3():
    st1=input("Enter the main")
    st2=input("Enter the substring")
    if(st2 in st1):
        print("Yes")
    else:
        print("No")