def q4():
    onestring = input("Enter One String:")
    removestring = input("Enter the string you want to delete:")
    finalstring = onestring.replace(removestring, "")
    print("Final String:",finalstring)
q4()






