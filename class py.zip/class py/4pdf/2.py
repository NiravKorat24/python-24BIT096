def q2():
    x=int(input("Enter the number whose table is required:"))
    for i in range(1,11):
        print(x,"X",i,"=",x*i)
