def q9():
    n = int(input("Enter N: "))
    for i in range(n, 0, -1):
        print(i)
