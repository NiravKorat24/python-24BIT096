def q5():
    strings = ["hello", "world", "python", "code"]
    for i in range(len(strings)):
        strings[i] = strings[i].upper()
    print(strings)
