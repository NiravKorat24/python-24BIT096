def q2():
        l=[(100,'Ronit',19),(99,'Yug',18),(120,'Krish',18),(159,'Tanmesh',18)]
        roll=[i[0] for i in l]
        name=[i[1] for i in l]
        age=[i[2] for i in l]
        print(roll,name,age)