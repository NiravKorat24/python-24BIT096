def q7():
    t=(1,2,3,5,6,7)
    t=list(t)
    t.remove(7)
    t=tuple(t)
    print(t)