def q2():
    d={"r":1}
    print("Empty") if(len(d)==0) else print("Not Empty")